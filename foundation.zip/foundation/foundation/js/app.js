$(document).foundation()

// $(".header-text h1").addClass("load");
// $(".header-text p").addClass("load");
